﻿
using System;
using System.Collections.Generic;

namespace RecipeApp
{
    class Program
    {
        static List<Ingredient> ingredients = new List<Ingredient>();
        static List<string> steps = new List<string>();

        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Recipe Creator");

            while (true)
            {
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Enter Recipe");
                Console.WriteLine("2. Scale Recipe");
                Console.WriteLine("3. Reset Quantities");
                Console.WriteLine("4. Clear All Data");
                Console.WriteLine("5. Quit");

                Console.Write("\nEnter your choice: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        EnterRecipe();
                        break;
                    case "2":
                        ScaleRecipe();
                        break;
                    case "3":
                        ResetQuantities();
                        break;
                    case "4":
                        ClearAllData();
                        break;
                    case "5":
                        Console.WriteLine("Exiting program. Goodbye!");
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        static void EnterRecipe()
        {
            Console.WriteLine("\nEnter Recipe Details:");

            ingredients.Clear();
            steps.Clear();

            // Get number of ingredients from the user
            Console.Write("Enter the number of ingredients: ");
            int numOfIngredients = int.Parse(Console.ReadLine());

            // Get details for each ingredient
            for (int i = 0; i < numOfIngredients; i++)
            {
                Console.WriteLine($"\nEnter details for Ingredient {i + 1}");
                Console.Write("Name: ");
                string name = Console.ReadLine();
                Console.Write("Quantity: ");
                double quantity = double.Parse(Console.ReadLine());
                Console.Write("Unit of Measurement: ");
                string unit = Console.ReadLine();

                // Create ingredient object and add to list
                ingredients.Add(new Ingredient(name, quantity, unit));
            }

            // Get number of steps from the user
            Console.Write("\nEnter the number of steps: ");
            int numOfSteps = int.Parse(Console.ReadLine());

            // Get details for each step
            for (int i = 0; i < numOfSteps; i++)
            {
                Console.WriteLine($"\nEnter details for Step {i + 1}");
                Console.Write("Description: ");
                string description = Console.ReadLine();

                // Add step description to list
                steps.Add(description);
            }

            Console.WriteLine("\nRecipe entered successfully.");
        }

        static void ScaleRecipe()
        {
            Console.Write("\nEnter scaling factor (0.5 for half, 2 for double, 3 for triple): ");
            double scaleFactor = double.Parse(Console.ReadLine());

            foreach (var ingredient in ingredients)
            {
                ingredient.Quantity *= scaleFactor;
            }

            Console.WriteLine("\nRecipe scaled successfully.");
        }

        static void ResetQuantities()
        {
            Console.WriteLine("\nResetting quantities to original values.");

            foreach (var ingredient in ingredients)
            {
                ingredient.ResetQuantity();
            }

            Console.WriteLine("Quantities reset successfully.");
        }

        static void ClearAllData()
        {
            Console.WriteLine("\nClearing all data.");

            ingredients.Clear();
            steps.Clear();

            Console.WriteLine("All data cleared successfully.");
        }
    }

    class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        private double originalQuantity;

        public Ingredient(string name, double quantity, string unit)
        {
            Name = name;
            Quantity = quantity;
            originalQuantity = quantity;
            Unit = unit;
        }

        public void ResetQuantity()
        {
            Quantity = originalQuantity;
        }
    }
}
